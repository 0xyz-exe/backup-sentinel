Automated Backup Sentinel Verification Fixture
